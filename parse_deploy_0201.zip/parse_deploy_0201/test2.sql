--/**����˵��*************************************************************
--�ű����ƣ�t1_rmm_dcor_armm_bc_acq_exg_plf_trx_dtl.hql
--����˵�����ͻ��������������յ�������ϸ��
--���·�ʽ��REPLACE
--�� �� �ˣ�����
--�������ڣ�2015-10-13
--�������ڣ���
--�������̣�./run.sh t1_rmm_dcor_armm_bc_acq_exg_plf_trx_dtl.hql 2015-09-30
--������ע��
--ά�����ڣ�
--ά �� �ˣ�
--ά����¼��
--************************************************************************/

--/**�趨���в���*********************************************************/
--use T_GPVT;

--set hive.exec.max.dynamic.partitions.pernode = 10000;
--set hive.exec.max.dynamic.partitions = 50000;
--set hive.exec.max.created.files = 5000000;
--set mapreduce.job.reduce.slowstart.completedmaps = 1.0;
--set mapreduce.map.speculative = false;
--set mapreduce.reduce.speculative = false;
--set hive.mapred.reduce.tasks.speculative.execution = false;
--set mapreduce.reduce.java.opts = -Xmx5888M;
--set mapreduce.reduce.memory.mb = 6144;
--set mapreduce.job.counters.limit = 240;
--set mapreduce.job.counters.max = 240;
--set hive.exec.compress.output=true;
--set mapred.output.compress=true;
--set mapred.output.compression.codec=org.apache.hadoop.io.compress.Lz4Codec;
--set io.compression.codecs=org.apache.hadoop.io.compress.Lz4Codec;


--/**����˵��************************************************************/


--/**��ҵ��ʱ��˵��*****************************************************/

--/**��ҵSQL���˵��*****************************************************/

--/**INSERT��书������������Ŀ��� ****/
INSERT OVERWRITE TABLE P_AHDP.COR_ARMM_BC_ACQ_EXG_PLF_TRX_DTL PARTITION(PRT_DT)
SELECT
 T2.CUST_UID                                                   AS  CUST_UID
,T2.OPN_BBK_ID                                                 AS  BBK_NBR
,T1.RCD_DT                                                     AS  RCD_DT
,T1.RCD_TM                                                     AS  RCD_TM
,T1.PPS_NOD_CD                                                 AS  PPS_NOD_CD
,T1.SRC_NOD_CD                                                 AS  SRC_NOD_CD
,T1.TRX_TYP_CD                                                 AS  TRX_TYP_CD
,T1.TRX_CD                                                     AS  TRX_CD
,T1.TRX_DEAL_NO                                                AS  TRX_DEAL_NO
,T1.TRX_AMT                                                    AS  TRX_AMT
,T1.CLR_AMT*T1.CLR_EXR                                         AS  CLR_AMT
,T1.BIL_AMT*T1.BIL_EXR                                         AS  BIL_AMT
,T1.BIL_CMSN_FEE*T1.BIL_EXR                                    AS  BIL_CMSN_FEE
,T1.CLR_EXR                                                    AS  CLR_EXR
,T1.BIL_EXR                                                    AS  BIL_EXR
,T1.MCH_TYP_CD                                                 AS  MCH_TYP_CD
,T1.AGN_ORG_CNR_CD                                             AS  AGN_ORG_CNR_CD
,T1.ISU_ORG_CNR_CD                                             AS  ISU_ORG_CNR_CD
,T1.CARD_ACC_TMN_ENC                                           AS  CARD_ACC_TMN_ENC
,T1.MCH_ID                                                     AS  MCH_ID
,T1.MCH_CUST_ID                                                AS  MCH_CUST_ID
,T1.TRX_CCY_CD                                                 AS  TRX_CCY_CD
,T1.CLR_CCY_CD                                                 AS  CLR_CCY_CD
,T1.BIL_CCY_CD                                                 AS  BIL_CCY_CD
,T1.CMSN_RAT                                                   AS  CMSN_RAT
,T1.ORIG_CMSN_FEE_CMSN_AMT                                     AS  ORIG_CMSN_FEE_CMSN_AMT
,T1.TGT_CMSN_FEE_CMSN_AMT                                      AS  TGT_CMSN_FEE_CMSN_AMT
,T1.CMSN_FEE_CCY_CD                                            AS  CMSN_FEE_CCY_CD
,T1.TRX_STS_CD                                                 AS  TRX_STS_CD
,T1.RCD_DT                                                     AS  PRT_DT
FROM P_BRTL_TDW.BRTL_BC_OVS_ACQ_EXG_PLF_TRX AS T1
 INNER JOIN P_BRTL_TDW.BRTL_PH_EAC_INF_S AS T2
    ON T1.MAIN_EAC_ID = T2.EAC_ID
WHERE T1.RCD_DT >= DATE_SUB('${hivevar:INPUT_DATE}',30)
 AND T1.RCD_DT <= '${hivevar:INPUT_DATE}'
 AND T2.PRT_DT = '${hivevar:INPUT_DATE}'

