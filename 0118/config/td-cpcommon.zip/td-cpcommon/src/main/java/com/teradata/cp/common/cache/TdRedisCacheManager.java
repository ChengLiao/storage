package com.teradata.cp.common.cache;

import com.teradata.adf.core.cache.CacheManager;
import com.teradata.util.StringUtil;
import org.springframework.cache.Cache;
import org.springframework.cache.support.SimpleValueWrapper;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import redis.clients.util.SafeEncoder;
import org.springframework.cache.Cache.ValueWrapper;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * Created by LIQJ on 8/10/2015.
 */
public class TdRedisCacheManager extends org.springframework.data.redis.cache.RedisCacheManager implements CacheManager {
    public static final int CACHE_MAXAGE_ALLLIVE = 60 * 60 * 24 * 100;// 100 day

    public static final int CACHE_MAXAGE_ZERO = 0;// 无限时间

    public static final int CACHE_MAXAGE_ONE_DAY = 24 * 60 * 60;// one day

    public static final int CACHE_MAXAGE_ONE_WEEK = 7 * 24 * 60 * 60;// one week

    public static final int CACHE_MAXAGE_THIRTY_MINUTE = 30 * 60;// 默认缓存时间 30分钟

    public static final String BEANNAME="tdCacheManager";

    public static final String CACHE_PREFIX="IDA-CACHE";

    public TdRedisCacheManager(RedisTemplate template) {
        super(template);
        this.redisTemplate = template;
    }

    private String defaultCacheName;

    private RedisTemplate redisTemplate;

    public String getDefaultCacheName() {
        return defaultCacheName;
    }

    public void setDefaultCacheName(String defaultCacheName) {
        this.defaultCacheName = defaultCacheName;
    }


    public RedisTemplate getRedisTemplate() {
        return redisTemplate;
    }

    public void setRedisTemplate(RedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    @Override
    public Object getData(String key) {
        return getData(getDefaultCacheName(),key);
    }

    @Override
    public Object getData(String cacheName, String key) {
        Object data = null;
        Cache  cache = getCache(cacheName);
        if(cache != null)
        {
            RedisTemplate template=(RedisTemplate)cache.getNativeCache();
            data=get(template,key);
        }
        return data;
    }

    private Object get (final RedisTemplate template,final String key){
        Object data = null;
        ValueWrapper valueWrapper = (ValueWrapper) template.execute(new RedisCallback<ValueWrapper>() {
            public ValueWrapper doInRedis(RedisConnection connection) throws DataAccessException {
                byte[] bs = connection.get(computeKey(template,key));

                return (bs == null ? null : new SimpleValueWrapper(template.getValueSerializer().deserialize(bs)));
            }
        }, true);
        if(valueWrapper != null)
            data = valueWrapper.get();
        return data;
    }

    @Override
    public List getMatchKeys(String pattern) {
        return getMatchKeys(getDefaultCacheName(),pattern);
    }

    @Override
    public List getMatchKeys(String cacheName, String keyPattern) {
        Cache cache = getCache(cacheName);
        if(cache != null){
            RedisTemplate template=(RedisTemplate)cache.getNativeCache();
            Set keys=getMatchKeys(template,keyPattern);
            return Arrays.asList(keys);
        }
        return null;
    }


    private Set getMatchKeys( RedisTemplate template,  String keyPattern) {
        final byte[] key_ = SafeEncoder.encode(keyPattern);
        Set<byte[]> rawKeys= (Set<byte[]>) template.execute(new RedisCallback<Set<byte[]>>() {
            public Set<byte[]> doInRedis(RedisConnection connection) throws DataAccessException {
                Set<byte[]> bs = connection.keys(key_);
                return bs;
            }
        }, true);
        return rawKeys;
    }

    @Override
    public void putData(String key, Object value) {
        putData(key,value,CACHE_MAXAGE_ALLLIVE);

    }

    @Override
    public void putData(String key, Object value, int maxAge) {
        putData(getDefaultCacheName(),key,value,maxAge);

    }

    @Override
    public void putData(String cacheName, String key, Object data) {
        putData(cacheName,key,data,CACHE_MAXAGE_ALLLIVE);
    }

    @Override
    public void putData(String cacheName, String key, Object data, int maxAge) {
        if(data==null)
            return;
        Cache cache = getCache(cacheName);
        if(cache != null){
            //cache.put(key, data);
            RedisTemplate template=(RedisTemplate)cache.getNativeCache();
            put(template, key, data);
            if(maxAge>0){
                setMaxAge(cacheName,key,maxAge);
            }
        }
    }

    @Override
    public void removeData(String key) {
        removeData(getDefaultCacheName(),key);
    }

    /*
     *
     * @see com.teradata.adf.core.cache.CacheManager#removeData(java.lang.String, java.lang.String)
     */
    @Override
    public void removeData(String cacheName, String key) {
        if(StringUtil.isNullOrEmpty(key)){                              //若key为空，则删除所有
            flush(cacheName);
        }
        else if(key.contains("*")){                                     //若key为模糊表达式，则模糊删除
            removeMatchData(cacheName,key);
        }
        else {
            Cache cache = getCache(cacheName);
            if(cache != null){
                RedisTemplate template=(RedisTemplate)cache.getNativeCache();
                template.delete(key);
            }
        }
    }

    public void removeData(String cacheName, final byte[] key) {
        Cache cache = getCache(cacheName);
        if(cache != null){
            RedisTemplate template=(RedisTemplate)cache.getNativeCache();
            template.execute(new RedisCallback<Object>() {
                public Object doInRedis(RedisConnection connection) throws DataAccessException {
                    connection.del(key);
                    return null;
                }
            }, true);
        }

    }

    public void removeMatchData( String keyPartern) {
        removeMatchData(getDefaultCacheName(),keyPartern);
    }

    public void removeMatchData(String cacheName, String keyPartern) {
        Set keys=(Set)getMatchKeys(cacheName,keyPartern).get(0);
        if(keys!=null){
            Iterator iter=keys.iterator();
            while (iter.hasNext()){
                Object obj1=iter.next();
                removeData(cacheName,(byte[])obj1);
            }
        }
    }





    /**
     *
     * @param cacheName
     */
    public void flush(String cacheName) {
        Cache cache = getCache(cacheName);
        if(cache != null){
            cache.clear();
            RedisTemplate template=(RedisTemplate)cache.getNativeCache();
            if(template!=null)
                flushAll(template);
        }

        removeMatchData("*");
    }

    private void flushAll(RedisTemplate template) {
        template.execute(new RedisCallback<Object>() {
            public Object doInRedis(RedisConnection connection) throws DataAccessException {
                connection.flushAll();
                return null;
            }
        }, true);

    }

    /**
     * 将key的生存时间设为seconds(以秒为单位)
     * @param cacheName
     * @param key
     * @param maxAge
     */
    public void setMaxAge(String cacheName, String key,int maxAge){

        Cache cache = getCache(cacheName);
        if(cache != null){
            RedisTemplate template=(RedisTemplate)cache.getNativeCache();
            template.expire(key, maxAge, TimeUnit.SECONDS);
        }
    }

    private byte[] computeKey(RedisTemplate template,Object key) {
        byte[] k = template.getKeySerializer().serialize(key);
        return k;
    }

    private void put(final RedisTemplate template,final Object key, final Object value) {
        final byte[] k = computeKey(template,key);

        template.execute(new RedisCallback<Object>() {
            public Object doInRedis(RedisConnection connection) throws DataAccessException {

                connection.multi();
                connection.set(k, template.getValueSerializer().serialize(value));
                connection.exec();
                return null;
            }
        }, true);
    }


    public <T> T getData(String key, Class<T> clazz)
    {
        // TODO Auto-generated method stub
        return null;
    }

}
