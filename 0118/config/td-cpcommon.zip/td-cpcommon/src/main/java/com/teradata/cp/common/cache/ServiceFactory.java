package com.teradata.cp.common.cache;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by liyh on 2015-01-08.
 */
public class ServiceFactory {

    private static ApplicationContext context = null;

    static {
        context = new ClassPathXmlApplicationContext("classpath*:spring/*.spring.xml");
    }

    public static <T> T getBean(String serviceName, Class<T> service) {
        if(serviceName != null) {
            return context.getBean(serviceName, service);
        }
        return null;
    }

    /**
     * 获得bean
     *
     * @param beanName bean名称
     * @return bean
     */
    public static Object getBean(String beanName) {
        if(beanName != null) {
            return context.getBean(beanName);
        }
        return null;
    }

}
