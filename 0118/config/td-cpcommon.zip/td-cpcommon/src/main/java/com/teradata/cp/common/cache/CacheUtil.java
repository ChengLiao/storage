package com.teradata.cp.common.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.List;

/**
 * Created by LIQJ on 8/13/2015.
 */

public class CacheUtil /*extends com.teradata.cache.CacheUtil */ {
//    public static final String PRIMARY_CACHE_NAME = "ecPrimaryCache";

    private static TdRedisCacheManager tdCacheManager;
/*    @Autowired
    public  void setTdCacheManager(TdRedisCacheManager tdCacheManager) {
       this.tdCacheManager = tdCacheManager;
    }*/

    public TdRedisCacheManager getTdCacheManager() {
        return tdCacheManager;
    }

    @Autowired
    public void setTdCacheManager(TdRedisCacheManager tdCacheManager) {
        CacheUtil.tdCacheManager = tdCacheManager;
    }

    public CacheUtil() {
    }

    public static List getKey(String str) {
        return tdCacheManager.getMatchKeys(str);
    }

/*    @PostConstruct
    public void init(){

    }*/


    public static Object getData(String key) {
        Object obj = new Object();
        if (tdCacheManager.getData(key) != null) {
            obj = tdCacheManager.getData(key);
        } else {
            obj = null;

        }
        return obj;
    }

    public static void putData(String key, Object value) {
        tdCacheManager.putData(key, value);
    }

    public static void remove(String key) {
        tdCacheManager.removeData(key);
    }

    public static void vaguRemove(String keyStr) {
        tdCacheManager.removeMatchData(keyStr);
    }


    public static Object getData(String name, Object key) {
        String keyName = name + "#" + key;

        return tdCacheManager.getData(keyName);
    }

    /**
     * 重写ehcache方法，指定了缓存所在的space.
     *
     * @param name
     * @param key
     * @param value
     */
    public static void putData(String name, Object key, Object value) {
        String keyName = name + "#" + key;
        tdCacheManager.putData(keyName, value);
    }

    /**
     * 如果设置缓存时间为0，则表示不限制缓存时常.
     *
     * @param key
     * @param value
     * @param maxAge
     */
    public static void putData(String key, Object value, int maxAge) {
        if (maxAge > 0) {
            tdCacheManager.putData(key, value, maxAge);
        } else {
            putData(key, value);
        }

    }

    /**
     * @param nameSpace
     * @param key
     * @return
     */
    public static boolean remove(String nameSpace, Object key) {
        String keyName = nameSpace + "#" + key;
        tdCacheManager.removeData(keyName);
        return true;
    }


}
